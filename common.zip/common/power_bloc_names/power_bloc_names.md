﻿The entry key is used as a localization key for the power bloc name

	power_bloc_name = {
		trigger = {	
			# Trigger evaluated in leader scope
			# scope:selected_identity - the identity that is selected in the power bloc formation panel
		}
	}
