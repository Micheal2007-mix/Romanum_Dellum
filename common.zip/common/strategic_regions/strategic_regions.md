Each state must be part of one and only one stategic region.
Every strategic region needs a capital and colour defined.

	strategic_region_name = {
		capital_province = province_id	# The province ID for the capital of the state, determines where the UI panel for the interest markers present appears
		map_color = { R% G% B% }		# The percentage of R G B colour for this region for the diplomatic map mode
		states = { state_key_list }		# The states included in this strategic region specified by key
	}